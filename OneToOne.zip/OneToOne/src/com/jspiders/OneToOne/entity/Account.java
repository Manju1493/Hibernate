package com.jspiders.OneToOne.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "account")
public class Account {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "acc_no")
	private int accno;
	
	@Column(name = "bnk_name")
	private String name;
	
	@Column(name = "brnch_name")
	private String branch;
	
	
	@OneToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "cus_id")
	private Customer customer = new Customer();
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	

	@Override
	public String toString() {
		return "Account [accno=" + accno + ", name=" + name + ", branch=" + branch + "]";
	}
}
