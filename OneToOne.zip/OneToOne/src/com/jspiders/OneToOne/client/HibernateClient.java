package com.jspiders.OneToOne.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.OneToOne.entity.Account;
import com.jspiders.OneToOne.entity.Customer;
import com.jspiders.OneToOne.util.HibernateUtil;

public class HibernateClient {

	public static void main(String[] args) {
		Session session = null;
		SessionFactory factory =HibernateUtil.getSessionFactory();
		session =  factory.openSession();
		
		Transaction tx= session.getTransaction();
		tx.begin();
		
		
		Account acc = new Account();
		acc.setName("BOI");
		acc.setBranch("BTR");
		
		Customer cus = new Customer();
		cus.setName("Allen");
		
		
		
	
		session.persist(acc);
		
		
		tx.commit();
		
		if(session!=null){
			session.close();
		}

	}

}
