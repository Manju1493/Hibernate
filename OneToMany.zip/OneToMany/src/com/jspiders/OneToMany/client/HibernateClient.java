package com.jspiders.OneToMany.client;

import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.jspiders.OneToMany.entity.Employee;
import com.jspiders.OneToMany.entity.Teamleader;
import com.jspiders.OneToMany.util.HibernateUtil;

public class HibernateClient {

	public static void main(String[] args) {
		Session session = null;
		SessionFactory factory =HibernateUtil.getSessionFactory();
		session =  factory.openSession();
		
		Transaction tx= session.getTransaction();
		tx.begin();
		
		Teamleader tl1 = new Teamleader();
		tl1.setName("allen");
		
		
		
		
		Employee emp1 = new Employee();
		emp1.setName("Blake");
		emp1.setTeamleader(tl1);
		
		Employee emp2 = new Employee();
		emp2.setName("Martin");
		emp2.setTeamleader(tl1);
		
		
		
	    Set<Employee> employees =  tl1.getEmployees();
	    employees.add(emp1);
	    employees.add(emp2);
	    
	    
	    session.persist(tl1);
		
		
		
		tx.commit();
		
		if(session!=null){
			session.close();
		}

	}

}
