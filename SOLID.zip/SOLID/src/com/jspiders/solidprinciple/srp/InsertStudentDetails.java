package com.jspiders.solidprinciple.srp;

public class InsertStudentDetails {
	
		

	public void insert(Student student) {
		System.out.println(student+" : All records of student is inserted to database");
		
	}
	

}
