package com.jspiders.solidprinciple.srp;

public class Mainclass {

	public static void main(String[] args) {
		Student student = new Student();
		student.setRegno(111);
		student.setName("Allen");
		student.setBranch("EEE");
		InsertStudentDetails studentDetails = 	new InsertStudentDetails();
		 studentDetails.insert(student);
	}

}
