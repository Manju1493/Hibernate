package com.jspiders.solidprinciples.isp;

public class Hp implements Printer {

	@Override
	public void print() {
		System.out.println("print by Hp");
	}

}
