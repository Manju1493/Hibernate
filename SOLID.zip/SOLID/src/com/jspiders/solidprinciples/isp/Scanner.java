package com.jspiders.solidprinciples.isp;

public interface Scanner {
	public void scan();

}
