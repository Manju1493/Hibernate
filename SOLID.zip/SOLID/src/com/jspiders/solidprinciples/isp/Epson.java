package com.jspiders.solidprinciples.isp;

public class Epson implements Scanner, Printer {

	@Override
	public void print() {
		System.out.println("print by Epson");
		
	}

	@Override
	public void scan() {
		System.out.println("scan by epson");
	
	}

}
