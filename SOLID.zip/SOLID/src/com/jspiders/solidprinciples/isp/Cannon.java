package com.jspiders.solidprinciples.isp;

public class Cannon implements Printer, Scanner, Faxer {

	@Override
	public void print() {
		System.out.println("print by cannon");
	}

	@Override
	public void scan() {
		System.out.println("scan by cannon");
	}

	@Override
	public void fax() {
		System.out.println("fax by cannon");

	}

}
