package com.jspiders.solidprinciples.isp;

public interface Faxer {
	public void fax();

}
