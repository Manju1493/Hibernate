package com.jspiders.solidprinciples.isp;

public interface Printer {
	public void print();

}
