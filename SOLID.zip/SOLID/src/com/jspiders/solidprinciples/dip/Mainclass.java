package com.jspiders.solidprinciples.dip;

public class Mainclass {

	public static void main(String[] args) {
		
		DisplayProducts products = new DisplayProducts();
		products.display();

	}

}
