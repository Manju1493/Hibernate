package com.jspiders.solidprinciples.dip;

public class DisplayProducts {
	public void display(){
		Product product = Productfactory.createProduct();
		int Products = product.readproduct();
		System.out.println("Products per page is:" + Products/10);
	
		
	}

}
