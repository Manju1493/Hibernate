package com.jspiders.solidprinciples.dip;

public class Productfactory {
	public static Product createProduct(){
		Product product = new SQLReposotory();
		return product;
		
	}

}
