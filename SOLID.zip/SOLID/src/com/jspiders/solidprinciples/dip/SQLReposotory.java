package com.jspiders.solidprinciples.dip;

public class SQLReposotory implements Product {

	@Override
	public int readproduct() {
		
		return 100;
	}

}
