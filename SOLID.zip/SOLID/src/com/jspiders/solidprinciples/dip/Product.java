package com.jspiders.solidprinciples.dip;

public interface Product {
	public int readproduct();

}
