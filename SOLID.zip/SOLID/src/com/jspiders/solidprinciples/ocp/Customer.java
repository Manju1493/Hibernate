package com.jspiders.solidprinciples.ocp;

public interface Customer {

	public boolean isLoyalCustomer();
}
