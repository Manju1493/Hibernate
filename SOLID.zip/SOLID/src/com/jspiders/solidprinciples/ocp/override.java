package com.jspiders.solidprinciples.ocp;

public @interface override {

}
