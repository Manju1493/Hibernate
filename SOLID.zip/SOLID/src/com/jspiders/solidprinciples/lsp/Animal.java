package com.jspiders.solidprinciples.lsp;

public interface Animal {

}
