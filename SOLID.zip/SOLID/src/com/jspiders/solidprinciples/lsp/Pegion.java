package com.jspiders.solidprinciples.lsp;

public class Pegion extends Bird {

	@Override
	public void fly() {
		System.out.println("Fly implementation of pegion");
		
	}

}
