package com.jspiders.solidprinciples.lsp;

public class Parrot extends Bird {

	@Override
	public void fly() {
		System.out.println("Fly implementation of parrot");
		
	}

}
