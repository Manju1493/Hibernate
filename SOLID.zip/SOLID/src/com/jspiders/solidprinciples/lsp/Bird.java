package com.jspiders.solidprinciples.lsp;

public abstract class Bird implements Animal {
	abstract public void fly();

}
