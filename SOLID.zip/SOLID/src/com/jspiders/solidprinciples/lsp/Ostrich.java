package com.jspiders.solidprinciples.lsp;

public class Ostrich implements Animal {

}
